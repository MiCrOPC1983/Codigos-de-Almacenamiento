<?php 

	header("location: ../");

?>