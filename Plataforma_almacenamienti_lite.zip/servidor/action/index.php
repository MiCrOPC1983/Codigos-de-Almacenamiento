<?php

	header("location: ../")

?>